
let btn = document.getElementById('btnRefresh');
btn.addEventListener('click', e=>changeValue());

let i=1;
async function changeValue(){
    let lbl = document.getElementById('lblResult');
    i-=-1;
    lbl.innerHTML="Valor:"+i;
}

async function init(){
    changeValue();
}

init();