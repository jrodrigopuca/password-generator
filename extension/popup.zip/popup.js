let btnRefresh = document.getElementById('btnRefresh');
let btnCopy = document.getElementById('btnCopy');
let lblResult = document.getElementById('lblResult');
let lblOriginal = document.getElementById('lblOriginal');

btnRefresh.addEventListener('click', e => changeValue());
btnCopy.addEventListener('click', e=>justCopy());

async function changeValue() {
    let pass= new Generator();
    let p=pass.getPass();
    lblResult.value =  p.pass;

    //quito todos los nodos y agrego uno con el resultado original, 
    // esto es para evitar usar el innerHtml
    while (lblOriginal.firstChild){
        lblOriginal.removeChild(lblOriginal.firstChild)
    }
    lblOriginal.appendChild(document.createTextNode(p.original))
}

async function justCopy(){
    lblResult.select();
        lblResult.focus();
        try{
            let copy= document.execCommand('copy');
        }
        catch(err){
            console.error(err)
        }
}

async function init() {
    changeValue();
}

init();

